const { Server } = require('socket.io');
const http = require('http');

const createSocketServer = (server) => {
  const io = new Server(server);
  return io;
};

module.exports = createSocketServer;
