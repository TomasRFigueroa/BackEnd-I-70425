const express = require('express');
const fs = require('fs');
const path = require('path');
const http = require('http');
const createSocketServer = require('./socket');

const app = express();
const server = http.createServer(app);
const io = createSocketServer(server);

const PORT = 8080;

const exphbs = require('express-handlebars');
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const productsRouter = require('./routes/products');
const cartsRouter = require('./routes/carts');

app.use('/api/products', productsRouter);
app.use('/api/carts', cartsRouter);

app.get('/', (req, res) => {
  const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/products.json'), 'utf-8'));
  res.render('home', { products });
});

app.get('/realtimeproducts', (req, res) => {
  const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/products.json'), 'utf-8'));
  res.render('realTimeProducts', { products });
});

io.on('connection', (socket) => {
  console.log('Un cliente se conectó');

  socket.emit('product-update', products());
  socket.on('new-product', (newProduct) => {
    const currentProducts = products();
    const newProductWithId = { ...newProduct, id: String(currentProducts.length + 1) };
    currentProducts.push(newProductWithId);
    fs.writeFileSync(path.join(__dirname, 'data/products.json'), JSON.stringify(currentProducts, null, 2));
    
    io.emit('product-update', currentProducts);
  });
});

server.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
